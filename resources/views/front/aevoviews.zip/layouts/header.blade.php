<div class="header">
    <div class="container">
        <div class="row" style="height: 99px;">
            <div class="col-auto align-self-center">
                <div class="row">
                <div class="col align-self-center">
                    <a href="{{route('index')}}">
                    <div class="site-name">
                        <img src="{{my_asset(get_setting('logo'))}}" class="ml-2"   alt="logo"   />
                    </div>
                    </a>
                </div>
                </div>
            </div>
        <div class="col">
            <div class="head-menu">
                <div class="row">
                    <div class="col text-lg-right mmff">
                        <div class="header-menu">
                            <ul>
                                <li>
                                    <a href="{{route('services')}}">Our Services</a>
                                </li>
                                <li>
                                    <a href="{{route('faq')}}">FAQ</a>
                                </li>
                                <li>
                                    <a href="{{route('api_docs')}}">API Documentation</a>
                                </li>
                                 <li>
                                    <a href="{{route('login')}}">Sign In</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-auto align-self-center mmff">
                        <a href="{{route('signup')}}" class=" btn btn-primary">
                           Register
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-auto for-mobile align-self-center">
            <div class="home-menu-btn px-3 py-4" onclick="homeMenuToggle()" style="">
            <i class="fas fa-grip-lines"></i>
            </div>
        </div>
        </div>
    </div>
</div>
