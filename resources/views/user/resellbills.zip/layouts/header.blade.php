
<div class="app-header">
    <div class="container-fluid">
        <div class="row row-80">
            <div class="col-auto align-self-center">
                <div class="dash-menu-btn" onclick="dashMenuToggle()">
                    <i class="fas fa-grip-lines"></i>
                </div>
            </div>
            
            <div class="col col-100 d-none d-md-inline-block align-self-center"> </div>
            
           
            <div class="col-auto align-self-center dash-menu-btn text-end" style="">
             
                <ul class="list-inline" style="">
                    <li class="list-inline-item"><button class="darkmode" onclick="change_mode()">
                                <i class="fa fa-sun"></i>
                                <i class="fa fa-moon"></i>
                            </button></li>
                        <li class="list-inline-item"><a href="{{ route('logout') }}"><i class="fa fa-power-off"></i></a></li>
                        
                        <li class="list-inline-item">
                            
                        <div class="app-user-box">
                        <div class="app-user-img">
                            <a href="{{ route('user.index') }}">
                                <img src="{{ static_asset('img/avatar.png') }}">
                            </a>
                        </div>
                        <div class="app-user-info">
                            <h4 class="app-user-name">{{ Auth::user()->username }} <img
                                    src="{{ static_asset('img/verified.png') }}" width="16" /></h4>
                            <div class="app-user-blnce">{{ format_price(Auth::user()->balance) }}</div>
                        </div>
                    </div>
                    
                    </li>
                    
                </ul>
             
            </div>
        </div><!-- row -->
    </div>
</div><!-- header -->


<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-S2CQHLJKVM">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-S2CQHLJKVM');
</script>